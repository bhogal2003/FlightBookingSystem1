package com.example.userservice1.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;
import com.example.userservice1.entity.User;
import com.example.userservice1.repository.*;

@Service
public class UserService {

    private final UserRepository repo;

    public UserService(UserRepository repo) {
        this.repo = repo;
    }

    public User saveUser(User user) {
        return repo.save(user);
    }

    public Optional<User> getUserById(Long id) {
        return repo.findById(id);
    }

    public User getUserByUsername(String username) {
        return repo.findByUsername(username).orElse(null);
    }

    public List<User> getAllUsers() {
        return repo.findAll();
    }

    public boolean deleteUser(Long id) {
        if (repo.existsById(id)) {
            repo.deleteById(id);
            return true;
        }
        return false;
    }

    public User updateUser(Long id, User updatedUser) {
        return repo.findById(id).map(user -> {
            user.setUsername(updatedUser.getUsername());
            user.setPassword(updatedUser.getPassword());
            user.setEmail(updatedUser.getEmail());
            return repo.save(user);
        }).orElse(null);
    }
}


