package com.example.flightservice1.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.example.flightservice1.entity.Flight;
import com.example.flightservice1.repository.FlightRepository;

@Service
public class FlightService {

    private final FlightRepository repo;

    public FlightService(FlightRepository repo) {
        this.repo = repo;
    }

    public Flight saveFlight(Flight flight) {
        return repo.save(flight);
    }

    public Optional<Flight> getFlightById(Long id) {
        return repo.findById(id);
    }

    public List<Flight> getAllFlights() {
        return repo.findAll();
    }

    public boolean deleteFlight(Long id) {
        if (repo.existsById(id)) {
            repo.deleteById(id);
            return true;
        }
        return false;
    }

    public Flight updateFlight(Long id, Flight updatedFlight) {
        return repo.findById(id).map(flight -> {
            flight.setFlightNumber(updatedFlight.getFlightNumber());
            flight.setDeparture(updatedFlight.getDeparture());
            flight.setDestination(updatedFlight.getDestination());
            flight.setDepartureTime(updatedFlight.getDepartureTime());
            flight.setArrivalTime(updatedFlight.getArrivalTime());
            flight.setAvailableSeats(updatedFlight.getAvailableSeats());
            return repo.save(flight);
        }).orElse(null);
    }
}

