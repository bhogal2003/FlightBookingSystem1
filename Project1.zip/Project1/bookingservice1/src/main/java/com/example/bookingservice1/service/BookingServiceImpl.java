package com.example.bookingservice1.service;

import com.example.bookingservice1.client.UserClient;
import com.example.bookingservice1.client.FlightClient;
import com.example.bookingservice1.dto.User;
import com.example.bookingservice1.dto.Flight;
import com.example.bookingservice1.entity.Booking;
import com.example.bookingservice1.repository.BookingRepository;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;

import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class BookingServiceImpl implements BookingService {

    private final BookingRepository bookingRepo;
    private final UserClient userClient;
    private final FlightClient flightClient;

    public BookingServiceImpl(BookingRepository bookingRepo, UserClient userClient, FlightClient flightClient) {
        this.bookingRepo = bookingRepo;
        this.userClient = userClient;
        this.flightClient = flightClient;
    }

    @Override
    @CircuitBreaker(name = "bookingService", fallbackMethod = "fallbackBookFlight")
    public Booking bookFlight(Long userId, Long flightId, int seatCount) {
        User user = userClient.getUserById(userId);
        if (user == null) throw new RuntimeException("User not found");

        Flight flight = flightClient.getFlightById(flightId);
        if (flight == null) throw new RuntimeException("Flight not found");

        if (flight.getAvailableSeats() < seatCount)
            throw new RuntimeException("Not enough seats available");

        flight.setAvailableSeats(flight.getAvailableSeats() - seatCount);
        flightClient.updateFlight(flightId, flight); // save seat update

        Booking booking = new Booking();
        booking.setUserId(userId);
        booking.setFlightId(flightId);
        booking.setSeatCount(seatCount);
        booking.setStatus("CONFIRMED");

        return bookingRepo.save(booking);
    }
    
    public Booking fallbackBookFlight(Long userId, Long flightId, int seatCount, Throwable t) {
        Booking failedBooking = new Booking();
        failedBooking.setUserId(userId);
        failedBooking.setFlightId(flightId);
        failedBooking.setSeatCount(seatCount);
        failedBooking.setStatus("FAILED");
        return failedBooking;
    }

    @Override
    public List<Booking> getBookings() {
        return bookingRepo.findAll();
    }

    @Override
    public Booking getBooking(Long id) {
    	
        return bookingRepo.findById(id).orElse(null);
    }

    @Override
    public boolean cancelBooking(Long id) {
        Optional<Booking> bookingOpt = bookingRepo.findById(id);
        if (bookingOpt.isPresent()) {
            Booking booking = bookingOpt.get();
            booking.setStatus("CANCELLED");
            bookingRepo.save(booking);
            return true;
        }
        return false;
    }
}
