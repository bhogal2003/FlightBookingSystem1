package com.example.bookingservice1.client;

import com.example.bookingservice1.dto.User;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "USER-SERVICE")
public interface UserClient {
    @GetMapping("/users/id/{id}")
    User getUserById(@PathVariable("id") Long id);
}

