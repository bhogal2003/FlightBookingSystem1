package com.example.bookingservice1.client;

import com.example.bookingservice1.dto.Flight;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

@FeignClient(name = "FLIGHT-SERVICE")
public interface FlightClient {
    @GetMapping("/flights/{id}")
    Flight getFlightById(@PathVariable("id") Long id);

    @PutMapping("/flights/{id}")
    Flight updateFlight(@PathVariable("id") Long id, @RequestBody Flight updatedFlight);
}



