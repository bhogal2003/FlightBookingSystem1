package com.example.bookingservice1.service;

import com.example.bookingservice1.entity.Booking;
import java.util.List;

public interface BookingService {
    Booking bookFlight(Long userId, Long flightId, int seatCount);
    List<Booking> getBookings();
    Booking getBooking(Long id);
    boolean cancelBooking(Long id);
}

